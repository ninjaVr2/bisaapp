/// Function with a single typed argument.
typedef Func1<A, R> = R Function(A a);
