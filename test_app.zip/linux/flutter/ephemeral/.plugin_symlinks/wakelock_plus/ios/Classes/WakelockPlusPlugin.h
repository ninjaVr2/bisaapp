#import <Flutter/Flutter.h>

@interface WakelockPlusPlugin : NSObject<FlutterPlugin>
@end
