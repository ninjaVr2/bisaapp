# record_linux

Linux specific implementation for record package called by record_platform_interface.
