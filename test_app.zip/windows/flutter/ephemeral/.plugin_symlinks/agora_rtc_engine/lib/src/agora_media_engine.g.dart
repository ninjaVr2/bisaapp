// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: non_constant_identifier_names, deprecated_member_use_from_same_package, unused_element

part of 'agora_media_engine.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

const _$AudioMixingDualMonoModeEnumMap = {
  AudioMixingDualMonoMode.audioMixingDualMonoAuto: 0,
  AudioMixingDualMonoMode.audioMixingDualMonoL: 1,
  AudioMixingDualMonoMode.audioMixingDualMonoR: 2,
  AudioMixingDualMonoMode.audioMixingDualMonoMix: 3,
};
