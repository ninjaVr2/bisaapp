#import <Flutter/Flutter.h>

@interface AgoraRtcNgPlugin : NSObject <FlutterPlugin>
@end
