#!/usr/bin/env bash

set -e

cd example/android

./gradlew test