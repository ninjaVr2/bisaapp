//
//  SampleHandler.h
//  ScreenSharing
//
//  Created by fenglang on 2022/8/16.
//

#import <ReplayKit/ReplayKit.h>

@interface SampleHandler : RPBroadcastSampleHandler

@end
